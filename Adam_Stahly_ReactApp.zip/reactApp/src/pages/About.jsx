import React from 'react';
const About = () => {
    return (
        <div className="container mt-4">
            <h1>About</h1>
            <p>This application was built for CSC3700.</p>
            <p>It allows users to view recipes and submit a contact form.</p>
        </div>
    );
}

export default About;